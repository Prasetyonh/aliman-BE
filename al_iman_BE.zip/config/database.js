import { Sequelize } from 'sequelize';

const db = new Sequelize('alimanbo_aliman', 'user', 'Tyo.20190140089', {
  host: 'api1.alimanboga.my.id',
  dialect: 'mysql'
});

export default db;
